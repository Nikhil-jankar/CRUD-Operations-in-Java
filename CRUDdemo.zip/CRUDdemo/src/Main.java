package com.example.crud;

public class Main {
    public static void main(String[] args) {
        // Add a new user
        //CrudOperations.createUser("John Doe", "john.doe@example.com", 25);

        // View all users in the database
        System.out.println("Users in the database:");
        CrudOperations.readUsers();

        // Update an existing user (with id = 1)
        //CrudOperations.updateUser(1, "Jane Doe", "jane.doe@example.com", 30);

        // View users again after the update
        //System.out.println("\nAfter update:");
        //CrudOperations.readUsers();

        // Delete a user (with id = 1)
        CrudOperations.deleteUser(4);
        CrudOperations.deleteUser(8);
        CrudOperations.deleteUser(9);


        // View users after deletion
        System.out.println("\nAfter deletion:");
        CrudOperations.readUsers();
    }
}
